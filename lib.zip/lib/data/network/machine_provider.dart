import 'package:flutter/cupertino.dart';

class PartProvider with ChangeNotifier {
  
}
