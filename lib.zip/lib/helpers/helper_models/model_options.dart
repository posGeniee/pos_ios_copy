class HelperModelOptions {
  String businessName;
  int businessId;
  HelperModelOptions(this.businessName, this.businessId);
}
